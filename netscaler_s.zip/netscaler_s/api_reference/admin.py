from .models import NetscalerCredentials
from django.contrib import admin

admin.site.register(NetscalerCredentials)